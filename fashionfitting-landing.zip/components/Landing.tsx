import React, { useEffect, useState } from 'react';

const Landing: React.FC = () => {
  // State to manage the reply-to field syncing with the email input
  const [email, setEmail] = useState('');
  
  // State to construct dynamic return URLs (next/error) based on current location
  // This ensures Formspree redirects back to the correct HashRouter path (e.g. domain.com/#/thanks)
  const [redirectUrls, setRedirectUrls] = useState({
    next: '/thanks',
    error: '/error'
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const origin = window.location.origin;
      const pathname = window.location.pathname;
      // Ensure we clean up any double slashes if pathname is just '/'
      const basePath = pathname === '/' ? '' : pathname;
      
      setRedirectUrls({
        next: `${origin}${basePath}#/thanks`,
        error: `${origin}${basePath}#/error`
      });
    }
  }, []);

  return (
    <div className="max-w-2xl mx-auto px-6 py-12">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6 leading-tight">
          패션 비즈니스의 혁신,<br />
          <span className="text-blue-600">패션피팅</span> 사전 접수 시작
        </h2>
        
        {/* Benefits Box */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 inline-block text-left mx-auto">
          <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">
            사전 신청 혜택
          </h3>
          <ul className="space-y-3">
            <li className="flex items-start">
              <svg className="w-5 h-5 text-blue-500 mt-0.5 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
              </svg>
              <span className="text-gray-700 font-medium">정식 런칭 시, 3개월간 20% 할인 혜택이 적용됩니다.</span>
            </li>
            <li className="flex items-start">
              <svg className="w-5 h-5 text-blue-500 mt-0.5 mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
              </svg>
              <span className="text-gray-700 font-medium">모델 1명 제작 무료 지원(런칭 한정)</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Form Section */}
      <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
        <div className="px-6 py-8 md:p-8">
          <h3 className="text-xl font-bold text-gray-900 mb-6">신청서 작성</h3>
          
          <form 
            action="https://formspree.io/f/xwvnlvrq" 
            method="POST"
            className="space-y-6"
          >
            {/* Hidden Config Fields */}
            <input type="hidden" name="_subject" value="[패션피팅] 신규 신청 접수" />
            
            {/* 
              Using dynamic full URLs for _next and _error to support HashRouter.
              Formspree requires absolute URLs or paths relative to the domain root.
              Since we use HashRouter (#/thanks), a relative path like "/thanks" 
              would redirect to domain.com/thanks, bypassing the React router.
            */}
            <input type="hidden" name="_next" value={redirectUrls.next} />
            <input type="hidden" name="_error" value={redirectUrls.error} />
            
            {/* Sync _replyto with the email input for correct "Reply-To" header in emails */}
            <input type="hidden" name="_replyto" value={email} />

            {/* Field: Company */}
            <div>
              <label htmlFor="company" className="block text-sm font-semibold text-gray-700 mb-2">
                업체명 <span className="text-red-500">*</span>
              </label>
              <input 
                type="text" 
                id="company"
                name="company" 
                required 
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors bg-gray-50 focus:bg-white outline-none"
                placeholder="업체명을 입력해주세요"
              />
            </div>

            {/* Field: Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">
                이메일 <span className="text-red-500">*</span>
              </label>
              <input 
                type="email" 
                id="email"
                name="email" 
                required 
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors bg-gray-50 focus:bg-white outline-none"
                placeholder="contact@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            {/* Field: Message */}
            <div>
              <label htmlFor="message" className="block text-sm font-semibold text-gray-700 mb-2">
                요청사항 <span className="text-red-500">*</span>
              </label>
              <textarea 
                id="message"
                name="message" 
                required 
                rows={4}
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors bg-gray-50 focus:bg-white outline-none resize-none"
                placeholder="궁금한 점이나 요청사항을 자유롭게 적어주세요."
              ></textarea>
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <button 
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-6 rounded-lg shadow-md transition-transform transform active:scale-[0.98] flex justify-center items-center"
              >
                신청 보내기
              </button>
            </div>
            
            <p className="text-xs text-gray-400 text-center mt-4">
              제출 버튼을 누르면 신청이 즉시 접수됩니다.
            </p>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Landing;