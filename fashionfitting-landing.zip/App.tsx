import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Landing from './components/Landing';
import Thanks from './components/Thanks';
import ErrorPage from './components/ErrorPage';

const App: React.FC = () => {
  return (
    <HashRouter>
      <div className="min-h-screen bg-gray-50 flex flex-col">
        {/* Simple Header */}
        <header className="bg-white border-b border-gray-100 py-4 sticky top-0 z-10">
          <div className="max-w-2xl mx-auto px-6 flex justify-center md:justify-start">
            <h1 className="text-xl font-bold tracking-tight text-brand-900">
              FashionFitting
            </h1>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Landing />} />
            <Route path="/thanks" element={<Thanks />} />
            <Route path="/error" element={<ErrorPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>

        {/* Simple Footer */}
        <footer className="bg-white py-6 mt-auto border-t border-gray-100">
          <div className="max-w-2xl mx-auto px-6 text-center text-sm text-gray-400">
            &copy; {new Date().getFullYear()} FashionFitting. All rights reserved.
          </div>
        </footer>
      </div>
    </HashRouter>
  );
};

export default App;